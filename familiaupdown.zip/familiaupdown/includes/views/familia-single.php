<?php

$item = wpfud_get_familia( $id ); 
 
var_dump( $item ); 
